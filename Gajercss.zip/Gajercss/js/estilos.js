$(".icono").click(function(){
    $("nav").animate({
        width: "toggle"
    });
});
